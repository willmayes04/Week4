#code to check whether an email is vaild

#function checks whether the email contains an @ or . symbol 
def EmailChecker(Email):
  SymbolFinder = Email.find("@")
  if SymbolFinder == -1:
    return False
  else:
    SymbolFinder = Email.find(".")
    if SymbolFinder == -1:
      return False
    else:
      return True

#takes an  input for a email to be checked
Email = input("Enter a vild email address: ")

#runs function
EmailChecker(Email)

#assigns variable to returned value
ValidEmail = EmailChecker(Email)

#runs a selection to decide what to string to output
if ValidEmail == True:
  ValidEmail = "valid"
else:
  ValidEmail = "invalid"

#outputs whetehr the email is valid or not
print("Your email is {}.".format(ValidEmail))