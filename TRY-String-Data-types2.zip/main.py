#String data types

# Subroutine to count charecters
def ShowLen(Surname):
  StringLength = len(Surname)
  print("There are {} letters in your surname, {}.".format(StringLength,Surname))

#Main
Surname = "Mayes"
ShowLen(Surname)

#------------------------------------------

#String data types

# Subroutine to count charecters
def ShowLen(Forename):
  StringLength = len(Forename)
  print("There are {} letters in your forename, {}.".format(StringLength,Forename))

#Main
Forename = "Will"
ShowLen(Forename)