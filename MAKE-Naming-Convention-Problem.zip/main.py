


def Translator(Sentence,LanguageChoice):
  if LanguageChoice == "kebab":
    Sentence = Sentence.lower()
    Sentence = Sentence.replace(" ","-")
  elif LanguageChoice == "snake":
    Sentence = Sentence.lower()
    Sentence = Sentence.replace(" ","_")
  elif LanguageChoice == "camel":
    Sentence = Sentence.lower()
    SecondPos = Sentence.find(" ")
    Sentence = Sentence.replace(Sentence.substring(SecondPos,SecondPos + 1),Sentence.substring(SecondPos,SecondPos + 1).toUpperCase());
  elif LanguageChoice == "pascal":
    Sentence = Sentence.title()
  else:
    Sentence = Sentence
  
  return Sentence

Sentence = ""
LanguageChoice = ""
Translator("I like pizza","kebab")
Output = Translator(Sentence,LanguageChoice)
print(Output)
Translator("The chair was black","snake")
Output = Translator(Sentence,LanguageChoice)
print(Output)
Translator("the room was messy","camel")
Output = Translator(Sentence,LanguageChoice)
print(Output)
Translator("the man was busy","pascal")
Output = Translator(Sentence,LanguageChoice)
print(Output)