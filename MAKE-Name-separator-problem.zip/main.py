#Code to split up name

# Function to split up name
def FullName(Name):
  Split = Name.find(" ")
  End = len(Name)
  Forename = Name[0:Split]
  Surname = Name[Split + 1:End]
  return Forename , Surname

#taking inputs
Name = input("Enter full name: ")
FullName(Name)
SplitName = FullName(Name)

#taking outputs
print("Your first name is {} and your last name is {}".format(SplitName[0],SplitName[1]))