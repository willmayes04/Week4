#string data types

#Function to process a phrase
def Find(Phrase,Word):
  Start = Phrase.find(Word)
  End = Start + len(Word) -1
  return Start , End

#Main
Phrase = "Code never lies; comments sometimes do. - Ron Jefferies"
Word = "Comments"
Start, End = Find(Phrase,Word);
print("'{}' can be found between charecters {} and {} in '{}'.".format(Word,Start,End,Phrase))