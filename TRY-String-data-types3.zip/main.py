#String datat types

#Subroutine to process a phrase
def Output(Phrase):
  print(Phrase[17:24])

#Main
Phrase = "First, solve the problem. Then, write the code.."
Output(Phrase)

#-------------------------------------------------------------

#String datat types

#Subroutine to process a phrase
def Output(Phrase):
  print(Phrase[32:37])

#Main
Phrase = "First, solve the problem. Then, write the code.."
Output(Phrase)

#-------------------------------------------------------------

#String datat types

#Subroutine to process a phrase
def Output(Phrase):
  print(Phrase[-16:-1])

#Main
Phrase = "First, solve the problem. Then, write the code.."
Output(Phrase)