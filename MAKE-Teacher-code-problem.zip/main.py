


def Initials(Fname,Mname,Sname):
  initial1 = Fname[0]
  initial2 = Mname[0]
  initial3 = Sname[0]
  return(initial1 + initial2 + initial3).upper()

Fname = input("Enter first name: ")
Mname = input("Enter middle name: ")
Sname = input("Enter last name: ")
Initials(Fname,Mname,Sname)
RealInitials = Initials(Fname,Mname,Sname)
print("Your initails are {}".format(RealInitials))