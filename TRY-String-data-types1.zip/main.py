# String data types

#Function to concatenate name
def FullName(String1,String2):
  return String1.upper() +" "+ String2.upper()

#Main
Forename = "Will"
Surname = "Mayes"
Student = FullName(Forename,Surname)
print("Full name: {}".format(Student))

#--------------------------------------------------

#Function to concatenate name
def FullName(String1,String2):
  return String1.lower() +" "+ String2.lower()

#Main
Forename = "Will"
Surname = "Mayes"
Student = FullName(Forename,Surname)
print("Full name: {}".format(Student))